import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

import static org.junit.Assert.*;

public class TestEmployeeDetails {
    EmpBusinessLogic empBusinessLogic;
    EmployeeDetails employee;

    @Before
    public void setUp() throws Exception {
        this.empBusinessLogic = new EmpBusinessLogic();
        this.employee = new EmployeeDetails();
    }
    //test to check appraisal
    @Test
    public void testCalculateAppriasal() {
  //      employee.setName("Linda");
  //      employee.setAge(25);
  //      employee.setMonthlySalary(8000);
        double appraisal = empBusinessLogic.calculateAppraisal(employee);
        assertEquals(500, appraisal, 0.0);
        System.out.println("appraisal checked");
    }
    // test to check yearly salary
    @Test
    public void testCalculateYearlySalary() {
        //employee.setName("Linda");
        //      employee.setAge(25);
              employee.setMonthlySalary(8000);
        double salary = empBusinessLogic.calculateYearlySalary(employee);
        assertEquals(96000, salary, 0.0);
        System.out.println("Year salary checked");
    }

    @Test
    public void setName() {
        employee.setName("earL");
        System.out.println("name set");
    }
    @Test
    public void getName() {
        employee.getName();
        System.out.println("got the name");
    }

    @Test
    public void setMonthlySalary() {
        employee.setMonthlySalary(8000);
        System.out.println("salary set");
    }
    @Test
    public void getMonthlySalary() {
        employee.getMonthlySalary();
        System.out.println("got salary");
    }

    @Test
    public void setAge() {
        employee.setAge(25);
        System.out.println("age set");
    }
    @Test
    public void getAge() {
        employee.getAge();
        System.out.println("got age");
    }
}